﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryDigitsCount
{
    class BinaryDigitsCounter
    {
        static void Main(string[] args)
        {
            long S = long.Parse(Console.ReadLine());
            //int n = int.Parse(Console.ReadLine());
            int[] n = new int[16];
            int num = int.Parse(Console.ReadLine());

        }
    }
}
